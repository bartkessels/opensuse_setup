# minimalism
---  
xenlism is Computer Graphic And Programming project to make something batter.   
xenlism is about minimalism and realism.   
xenlism minimalism is Gnome / GTK theme for Gnome 3.x desktop environment.     
xenlism minimalism inspired by Elementary OS.    
 

xenlism minimalism under developments.
xenlism minimalism beta 2 base on [Arc Theme](https://github.com/horst3180/Arc-theme).

    
xenlism minimalism is [GPL](http://www.gnu.org/licenses/gpl-3.0.txt). 
Buy coffee for me Paypal exenatt@gmail.com

if you need to discuss or show your desktop and share idea. All at [xenlism Community](https://plus.google.com/communities/109015399598666540563).   
   
#Installations
Install And More Info at [Github.io](https://xenlism.github.io/minimalism).    

![screenshot](https://raw.githubusercontent.com/xenlism/minimalism/master/Screenshot/xenlism_minimalism_cover1.png)   
![screenshot](https://raw.githubusercontent.com/xenlism/minimalism/master/Screenshot/xenlism_minimalism_cover2.png)    
![screenshot](https://raw.githubusercontent.com/xenlism/minimalism/master/Screenshot/xenlism_minimalism_cover3.png)    
    

